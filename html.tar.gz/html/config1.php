<?php
$host = '127.0.0.1';
$port = '5432';
$dbname = 'ma_base_de_donnees';
$user = 'etudiant';
$password = 'Pavi3l3b3st.';
?> 